clear;clc
% initial conditions
phi0= 0;            %in degree
theta0= pi*0.98/2;  %in degree
psi0= 0;           %in degree
V0=30;             %resultant
u0     = 0; %sqrt(V0^2/(1+(tan(theta0))^2));
v0     = 0;%V0*tan(phi0);     % initial velocity along body y-axis
w0     = 0;%u0*tan(theta0);     % initial velocity along body z-axis
p0     = 0;     % initial body frame roll rate
q0     = 0;     % initial body frame pitch rate
r0     = 0;     % initial body frame yaw rate

%physical parameters of airframe
d     = 0.09; %m
d_arm = 0.89; %0.29; %m
C_N   = 9.804;%10.917;
C_A   = 0.567; %0.0055;%
%Ts = 0.01;
%Import Thrust data
filePath = 'rocket_390N.xlsx';
thrust_profile = readmatrix(filePath);
g = 9.81;
mass = 5.4;
Ix = 0.824;%0.6465;
Iy = 1.135;%0.3048;
Iz = 1.759;%0.9359;
Ixz= 0.120;
I = [Ix 0  0
     0  Iy 0
     0  0  Iz];
b             = 1.829;
c             = 0.036;
S             = 0.006;
rho           = 1.2682;

% State-space model parameters
    n_measure   = 1;                 % number of measurement
    Qc          = 1e-3*diag(ones(1,3));
    Rsim        = 1e-3*diag(ones(1,n_measure));

% Solver parameters
    Ts          = 0.01;              % sampling time

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% aerodynamic coefficients longitudinal
C_L_0         = 0.127;
C_L_alpha     = 4.5287;
C_L_q         = 0.0;
C_L_delta_e   = -0.25;
C_D_0         = 0.029;
C_D_alpha     = 0.20;
C_D_p         = 0.0165;
C_D_q         = 0.0;
C_D_delta_e   = 0.0;
C_m_0         = -0.0108;
C_m_alpha     = -0.28;
C_m_q         = -2.4;
C_m_delta_e   = -0.35;
alpha0        = -0.0387;%0.4712;
% LQR, longitudinal parameters
C_X_0         = -C_D_0*cos(alpha0)+C_L_0*sin(alpha0);
C_X_alpha     = -C_D_alpha*cos(alpha0)+C_L_alpha*sin(alpha0);
C_X_q         = -C_D_q*cos(alpha0)+C_L_q*sin(alpha0);
C_X_delta_e   = -C_D_delta_e*cos(alpha0)+C_L_delta_e*sin(alpha0);
C_Z_0         = -C_D_0*sin(alpha0)-C_L_0*cos(alpha0);
C_Z_alpha     = -C_D_alpha*sin(alpha0)-C_L_alpha*cos(alpha0);
C_Z_q         = -C_D_q*sin(alpha0)-C_L_q*cos(alpha0);
C_Z_delta_e   = -C_D_delta_e*sin(alpha0)-C_L_delta_e*cos(alpha0);

% aerodynamic coefficients of lateral
C_Y_0         = 0.0;
C_Y_beta      = -0.78;
C_Y_p         = 0.0;
C_Y_r         = 0.0;
C_Y_delta_a   = 0.0;
C_Y_delta_r   = -0.25;
C_ell_0       = 0.0;
C_ell_beta    = -0.15;
C_ell_p       = -0.30;
C_ell_r       = 0.152;
C_ell_delta_a = 0.054;
C_ell_delta_r = 0.0974;
C_n_0         = 0.0;
C_n_beta      = 0.282;
C_n_p         = 0.0235;
C_n_r         = -0.347;
C_n_delta_a   = 0.059;
C_n_delta_r   = -0.0289;
%C_prop        = 1.0;

% Gamma parameters from uavbook page 36
Gamma  = Ix*Iz-Ixz^2;
Gamma1 = (Ixz*(Ix-Iy+Iz))/Gamma;
Gamma2 = (Iz*(Iz-Iy)+Ixz*Ixz)/Gamma;
Gamma3 = Iz/Gamma;
Gamma4 = Ixz/Gamma;
Gamma7 = (Ix*(Ix-Iy)+Ixz*Ixz)/Gamma;
Gamma8 = Ix/Gamma;


% Aerodynamic coefficient of lateral
Cp_0          = Gamma3*C_ell_0+Gamma4*C_n_0;
Cp_beta       = Gamma3*C_ell_beta+Gamma4*C_n_beta;
Cpp           = Gamma3*C_ell_p+Gamma4*C_n_p;
Cp_r          = Gamma3*C_ell_r+Gamma4*C_n_r;
Cp_delta_a    = Gamma3*C_ell_delta_a+Gamma4*C_n_delta_a;
Cp_delta_r    = Gamma3*C_ell_delta_r+Gamma4*C_n_delta_r;
Cr_0          = Gamma4*C_ell_0+Gamma8*C_n_0;
Cr_beta       = Gamma4*C_ell_beta+Gamma8*C_n_beta;
Cr_r          = Gamma4*C_ell_r+Gamma8*C_n_r;
Cr_delta_a    = Gamma4*C_ell_delta_a+Gamma8*C_n_delta_a;
Cr_delta_r    = Gamma4*C_ell_delta_r+Gamma8*C_n_delta_r;
Vm = 10;
delta_e = 0;%deflection pitch angle
delta_a = 0.2617994; %deflection yaw angle
delta_r = 0.174533;%0.3490659; %deflection roll angle
diff_T_p_delta_t = 6.818;
beta = 0.5; %sideslip angle
alpha = -0.0387;%10*pi/180; %Angle of attack
theta = 0;
% compute value of matrix A & B Longitudinal
X_u = (u0*rho*S/mass)*(C_X_0+C_X_alpha*alpha+C_X_delta_e*delta_e)-(rho*S*w0*C_X_alpha/(2*mass))+(rho*S*c*C_X_q*u0*q0/(4*mass*Vm));
X_w = (-q0)+(w0*rho*S/mass)*(C_X_0+C_X_alpha*alpha+C_X_delta_e*delta_e)+(rho*S*c*C_X_q*w0*q0/(4*mass*Vm))+(rho*S*C_X_alpha*u0/(2*mass));
X_q = (w0)+(rho*Vm*S*C_X_q*c/(4*mass));
Z_u = q0+(u0*rho*S/mass)*(C_Z_0+C_Z_alpha*alpha+C_Z_delta_e*delta_e)-(rho*S*C_X_alpha*w0/(2*mass))+(u0*rho*S*C_Z_q*c*q0/(4*mass*Vm));
Z_w = (w0*rho*S/mass)*(C_Z_0+C_Z_alpha*alpha+C_Z_delta_e*delta_e)+(rho*S*C_Z_alpha*u0/(2*mass))+(rho*w0*S*c*C_Z_q*q0/(4*mass*Vm));
Z_q = u0+rho*(Vm)*S*C_Z_q*c/(4*mass);
M_u = (u0*rho*S*c/Iy)*(C_m_0+C_m_alpha*alpha+C_m_delta_e*delta_e)-(rho*S*c*C_m_alpha*w0/(2*Iy))+(rho*S*(c)^2*C_m_q*q0*u0/(4*Iy*Vm));
M_w = (w0*rho*S*c/Iy)*(C_m_0+C_m_alpha*alpha+C_m_delta_e*delta_e)+(rho*S*c*C_m_alpha*u0/(2*Iy))+(rho*S*(c)^2*C_m_q*q0*w0/(4*Iy*Vm));
M_q = rho*Vm*S*(c)^2*C_m_q/(4*Iy);
M_delta_e = rho*(Vm^2)*S*c*C_m_delta_e/(2*Iy);
Z_delta_e = rho*(Vm^2)*S*C_Z_delta_e/(2*mass);
X_delta_e = rho*(Vm^2)*S*C_X_delta_e/(2*mass);
X_delta_t = (diff_T_p_delta_t);
%longi = [ u_initial; w_initial; q_initial; theta_initial; Ze0];
%longd=[u0; w0; q0; theta0];
% compute Matrix A, B & C
A_long = [X_u  X_w  X_q  -g*cos(theta0) ; ...
         Z_u  Z_w  Z_q  -g*sin(theta0)/(Vm*cos(alpha0));
         M_u  M_w  M_q  0;
          0  0  1  0 ]
B_long = [X_delta_e                 X_delta_t; ...
          Z_delta_e                     0;  
          M_delta_e                     0; 
                0                       0]
C_long = [0 0 0 1];
%C_lon = [0 0 0 0 1; u0/Vm w0/Vm 0 0 0];
D_long = 0;

% Qx & Qu
Q_long = 1e3*diag([1 1 1 1]);
R_long = [1 0
          0 1];
% K = lqr(A_lon,B_lon,Qx,R);
K_long = lqr(A_long,B_long,Q_long,R_long)
M_long = -(C_long*(A_long-B_long*K_long)^-1*B_long);
Kr_long= M_long'*(M_long*M_long')^-1
e_longi = [0; 0; 0; 2*pi/180];
%%%Closed loop system
% reglator_sys = ss((A_long - B_long*K_long), B_long, C_long, D_long);
sys = ss((A_long - B_long* K_long), B_long, C_long, D_long);

%%% simulation
%(1) Simulation without theta disturbance =2 degree with input zero signal 
 t=0:0.1:10;
u_input=[zeros(1,numel(t));zeros(1,numel(t))];
%u_input=[ff;kk];


[Y,T,e]=lsim(sys,u_input,t,e_longi);
%[y,t,x] = initial(sys, x0, t);
%[y,t,e] = step(sys, t);
% figure(3)
% plot(t,theta0*pi/180-e(:,4),'r',t,theta0*pi/180+zeros(1,numel(t)),'b')
% title('Pitch angel Response with theta disturbance =10 degree and zero inputs')
% xlabel('time') 
% legend('theta','theta0')
%LQR lateral
%lati = [ v0; p0; r0; phi0; psi0];
%latd=[v0; p0; r0; phi0; psi0];

%lateral state space model coefficient
Y_v       = ((rho*S*b*v0)/4*mass*Vm*C_Y_p*p0+C_Y_r*r0+(rho*S*v0)/mass*(C_Y_0+C_Y_beta*beta)+C_Y_delta_a*delta_a+C_Y_delta_r*delta_r)+(rho*S*C_Y_beta)/2*mass*sqrt(u0^2+w0^2);
Y_p       = w0+(rho*Vm*S*b)/(4*mass)*(C_Y_p);
Y_r       = -u0+(rho*Vm*S*b)/(4*mass)*(C_Y_r);
Y_delta_a = (rho*Vm*S*b)/(4*mass)*C_Y_delta_a;
Y_delta_r = (rho*Vm*S*b)/(4*mass)*C_Y_r;
L_v       = (rho*S*b^2*v0)/(4*Vm)*(Cp_r*p0+Cp_r*r0)+rho*S*b*v0*(Cp_0+Cp_beta*beta+Cp_delta_a*delta_a+Cp_delta_r*delta_r)+(rho*S*b*Cp_beta)/2*sqrt(u0^2+w0^2);
L_p       = Gamma1*q0+(rho*Vm*S*b^2)/4*Cpp;
L_r       = Gamma2*q0+(rho*Vm*S*b^2)/4*Cpp;
L_delta_a = (rho*Vm^2*S*b/2)*Cp_delta_a;
L_delta_r = (rho*Vm^2*S*b)/2*Cp_delta_r;
N_v       = (rho*S*b^2*v0)/4*Vm*(Cr_r*r0)+rho*S*b*v0*(Cr_0+Cr_beta*beta+Cr_delta_a*delta_a+Cr_delta_r*delta_r)+(rho*S*b*Cr_beta)/2*sqrt(u0^2+w0^2);
N_p       = Gamma7*q0+(rho*Vm*S*b^2)/4*(Cr_r);
N_r       = -Gamma1*q0+(rho*Vm*S*b^2)/4*Cr_r;
N_delta_a = (rho*Vm^2*S*b/2)*(Cr_delta_a);
N_delta_r = (rho*Vm^2*S*b/2)*(Cr_delta_r);
A_14      = g*cos(theta0)*cos(phi0);
A_43      = cos(phi0)*tan(theta0);
A_44      = q0*cos(phi0)*tan(theta0)-r0*sin(phi0)*tan(theta0);
A_53      = cos(phi0)*sec(theta0);
A_54      = p0*cos(phi0)*sec(theta0)-r0*sin(phi0)*sec(theta0);
% Matrice A and B
A_lat = [Y_v  Y_p  Y_r  A_14  0;...
         L_v  L_p  L_r  0     0;
         N_v  N_p  N_r  0     0;
         0    1   A_43  A_44  0;
         0    0   A_53  A_54  0]
B_lat = [Y_delta_a  Y_delta_r;...
         L_delta_a  L_delta_r;
         N_delta_a  N_delta_r;
         0          0        ;
         0          0        ]
C_lat = [0  0  0  1  0];
        % 0  0  0  0  1];
D_lat = 0;
Q_lat = 1e-2*diag([1 1 1 1 1]);
R_lat = 1e3*[1  0
             0  1];
K_lat = lqr(A_lat,B_lat, Q_lat,R_lat)
%K2_lat = lqr(A_lat,B_lat, Q_lat,R_lat)
M_lat = -(C_lat*(A_lat-B_lat*K_lat)^-1*B_lat);
Kr_lat= M_lat'*(M_lat*M_lat')^-1
e_lati = [0; 0; 0; -10*pi/180; -10*pi/180];
sys_lat = ss((A_lat - B_lat* K_lat), B_lat, C_lat, D_lat);
% %%% simulation
% %(1)Simulation without theta disturbance =2 degree with input zero signal 
t=0:0.1:16;
t_lat=0:0.1:16;
u_lat_input=[zeros(1,numel(t_lat));zeros(1,numel(t_lat))];

[Y_lat,T_lat,e_lat]=lsim(sys_lat,u_lat_input,t,e_lati);

figure(1)
plot(t,phi0*pi/180-e_lat(:,4),'r',t,phi0*pi/180+zeros(1,numel(t_lat)),'b')
title('Roll angel Response with phi disturbance =10 degree and zero inputs')
xlabel('time') 
legend('phi','phi0')

figure(2)
plot(t,psi0*pi/180-e_lat(:,5),'r',t,psi0*pi/180+zeros(1,numel(t_lat)),'b')
title('Yaw angle Response with Roll disturbance =10 degree and zero inputs')
xlabel('time') 
legend('psi','psi0')
